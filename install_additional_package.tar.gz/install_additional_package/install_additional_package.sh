#!/bin/bash

WORKDIR="./rpm_file"
rpm -ivh ${WORKDIR}/epel-release-latest-8.noarch.rpm

dnf install -y libpng15 netpbm ImageMagick

rpm -ivh ${WORKDIR}/bison-devel-3.0.4-2.el7.x86_64.rpm
rpm -ivh ${WORKDIR}/libdb4-4.8.30-30.el8.x86_64.rpm
rpm -ivh ${WORKDIR}/libdb4-devel-4.8.30-30.el8.x86_64.rpm
rpm -ivh ${WORKDIR}/centos-indexhtml-8.0-0.el8.noarch.rpm
rpm -ivh ${WORKDIR}/lynx-2.8.9-4.el8.x86_64.rpm
rpm -ivh ${WORKDIR}/netpbm-devel-10.82.00-7.el8.x86_64.rpm
rpm -ivh ${WORKDIR}/xloadimage-4.1-18.el7.x86_64.rpm
rpm -ivh ${WORKDIR}/libmcrypt-2.5.8-26.el8.x86_64.rpm
rpm -ivh ${WORKDIR}/libmcrypt-devel-2.5.8-26.el8.x86_64.rpm
